package com.capgemini.springboot.cruddemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.springboot.cruddemo.entity.Employee;

@Repository
public class EmployeeDAOJpaImpl implements EmployeeDAO {

	private EntityManager entityManager;

	@Autowired
	public EmployeeDAOJpaImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}

	@Override
	public List<Employee> findAllEmployees() {
		// create a query
		Query theQuery = entityManager.createQuery("from Employee");

		// execute a query and get result list
		List<Employee> employees = theQuery.getResultList();

		// return the result list
		return employees;
	}

	@Override
	public Employee findEmployeeById(int id) {
		// get the Employee
		Employee employee = entityManager.find(Employee.class, id);
		
		// return the employee
		return employee;
	}

	@Override
	public void save(Employee employee) {
		
		// save or update the employee
		Employee theemployee = entityManager.merge(employee);
		
		// update the employee with id from db
		employee.setId(theemployee.getId());
		
		
	}

	@Override
	public void deleteById(int id) {
		
		// delete the object with primary key
		Query theQuery = entityManager.createQuery("delete from Employee where id=:employeeId");
		theQuery.setParameter("employeeId", id);
		
		theQuery.executeUpdate();

	}

}
