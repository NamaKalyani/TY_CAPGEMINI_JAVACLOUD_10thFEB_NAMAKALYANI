package com.capgemini.springboot.demo.myFirstApp.rest;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirstRestController {
	
	// Inject properties for: coach.name, team.name
	@Value("${coach.name}")
	private String coachName;
	
	@Value("${team.name}")
	private String teamName;
	
	// expose new end point for team info
	
	@GetMapping("/teaminfo")
	public String getTeamInfo() {
		return "Coach name :"+ coachName +",Team name :"+ teamName;
	}

	// expose "/" that return Hello World
	@GetMapping("/")
	public String sayHello() {
		return "Hello World Time on Server is :" + LocalDateTime.now();
	}
	
	@GetMapping("/workout")
	public String dailyWorkout() {
		return "Run 100 meters daily";
	}
	
}
