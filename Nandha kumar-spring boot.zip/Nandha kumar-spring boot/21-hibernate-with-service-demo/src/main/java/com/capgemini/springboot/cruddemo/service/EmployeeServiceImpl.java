package com.capgemini.springboot.cruddemo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springboot.cruddemo.dao.EmployeeDAO;
import com.capgemini.springboot.cruddemo.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDAO employeeDAO;

	@Autowired
	public EmployeeServiceImpl(EmployeeDAO thEmployeeDAO) {
		employeeDAO = thEmployeeDAO;
	}

	@Override
	@Transactional
	public List<Employee> findAllEmployees() {
		
		return employeeDAO.findAllEmployees();
	}

	@Override
	@Transactional
	public Employee findEmployeeById(int id) {
		
		return employeeDAO.findEmployeeById(id);
	}

	@Override
	@Transactional
	public void save(Employee employee) {
		employeeDAO.save(employee);
	}

	@Override
	@Transactional
	public void deleteById(int id) {
		employeeDAO.deleteById(id);
	}

}
