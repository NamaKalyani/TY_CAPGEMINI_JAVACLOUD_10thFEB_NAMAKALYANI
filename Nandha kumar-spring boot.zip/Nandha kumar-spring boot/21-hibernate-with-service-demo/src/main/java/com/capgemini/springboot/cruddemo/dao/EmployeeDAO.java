package com.capgemini.springboot.cruddemo.dao;

import java.util.List;

import com.capgemini.springboot.cruddemo.entity.Employee;

public interface EmployeeDAO {

	public List<Employee> findAllEmployees();

	public Employee findEmployeeById(int id);

	public void save(Employee employee);

	public void deleteById(int id);
}
