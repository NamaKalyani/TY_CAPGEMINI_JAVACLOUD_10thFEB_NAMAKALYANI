package com.tyss.capgemini.springBoot.demo.myspringbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyspringbootappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyspringbootappApplication.class, args);
	}

}
