package com.tyss.capgemini.springboot.cruddemo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tyss.capgemini.springboot.cruddemo.entity.Product;

@Repository
public class UserDAOHibernateImpl implements ProductDAO{
	// define field for entitymanager	
		private EntityManager entityManager;
			
		// set up constructor injection
		@Autowired
		public UserDAOHibernateImpl(EntityManager theEntityManager) {
			entityManager = theEntityManager;
		}
		
		
		@Override
		public List<Product> findAll() {

			// get the current hibernate session
			Session currentSession = entityManager.unwrap(Session.class);
			
			// create a query
			Query<Product> theQuery =
					currentSession.createQuery("from Product", Product.class);
			
			// execute query and get result list
			List<Product> employees = theQuery.getResultList();
			
			// return the results		
			return employees;
		}


		@Override
		public Product findById(int theId) {
			// get the current hibernate session
			Session currentSession = entityManager.unwrap(Session.class);
			
			// get the employee
			
			Product theEmployee = currentSession.get(Product.class, theId);
			// return the Employee
			return theEmployee;
		}


		@Override
		public void save(Product theEmployee) {
			
			 // get the current hibernate session
			Session currentSession = entityManager.unwrap(Session.class);
			
			// save employee
			currentSession.saveOrUpdate(theEmployee);
			
		}


		@Override
		public void deleteById(int theId) {
			
			// get the current hibernate session
		Session currentSession = entityManager.unwrap(Session.class);
			
		// delete the object with primary key
		Query theQuery = currentSession.createQuery("delete from Product where id=:ProductId");
		
		theQuery.setParameter("ProductId", theId);
		theQuery.executeUpdate();
			
		}


}
