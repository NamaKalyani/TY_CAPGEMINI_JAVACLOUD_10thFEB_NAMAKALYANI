package com.tyss.capgemini.springboot.cruddemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import net.bytebuddy.build.ToStringPlugin.Exclude;

@Entity
@Table(name="product")
public class Product {
	
	// define fields
	
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="id")
		private int id;
		
		@Column(name="product_name")
		private String productName;
		
		
		@Column(name="product_image_url")
		private String productImageUrl;
		
		
		@Column
		private double productPrice;
		
		@Column
		private String productDesc;
			
		// define constructors
		
		public Product() {
			
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getProductName() {
			return productName;
		}

		public void setProductName(String productName) {
			this.productName = productName;
		}

		public String getProductImageUrl() {
			return productImageUrl;
		}

		public void setProductImageUrl(String productImageUrl) {
			this.productImageUrl = productImageUrl;
		}

		public double getProductPrice() {
			return productPrice;
		}

		public void setProductPrice(double productPrice) {
			this.productPrice = productPrice;
		}

		public String getProductDesc() {
			return productDesc;
		}

		public void setProductDesc(String productDesc) {
			this.productDesc = productDesc;
		}

		@Override
		public String toString() {
			return "Product [id=" + id + ", productName=" + productName + ", productImageUrl=" + productImageUrl
					+ ", productPrice=" + productPrice + ", productDesc=" + productDesc + ", getId()=" + getId()
					+ ", getProductName()=" + getProductName() + ", getProductImageUrl()=" + getProductImageUrl()
					+ ", getProductPrice()=" + getProductPrice() + ", getProductDesc()=" + getProductDesc()
					+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
					+ "]";
		}

		
		
}
