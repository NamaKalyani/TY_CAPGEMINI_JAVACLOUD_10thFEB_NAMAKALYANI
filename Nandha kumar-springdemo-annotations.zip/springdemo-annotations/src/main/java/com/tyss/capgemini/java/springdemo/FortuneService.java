package com.tyss.capgemini.java.springdemo;

public interface FortuneService {
	public String getFortune();

}
