package com.tyss.capgemini.spring_demo_annotations;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class AnnotationBeanScopeDemo {

	public static void main(String[] args) {

		// read the spring configuration file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		// get the bean from spring container
		Coach coach = context.getBean("tennisCoach", Coach.class);

		Coach alphaCoach = context.getBean("tennisCoach", Coach.class);

		// Check if they are the same
		boolean result = (coach == alphaCoach);

		// print out the results
		System.out.println("pointing to the same object :" + result);

		System.out.println("memory location  for the coach :" + coach);

		System.out.println(" memory location for the coach: " + alphaCoach );

		// close the context
		context.close();

	}

}
