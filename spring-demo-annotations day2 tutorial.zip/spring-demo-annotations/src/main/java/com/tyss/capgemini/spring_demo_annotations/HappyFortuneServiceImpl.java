package com.tyss.capgemini.spring_demo_annotations;

import org.springframework.stereotype.Component;

@Component
public class HappyFortuneServiceImpl implements FortuneService {

	@Override
	public String getFortune() {
		
		return "Today is not our lucky day!.............";
	}

}
