package com.tyss.capgemini.spring_demo_annotations;

public interface Coach {
	 
	public String getDailyWorkout();
	
	public String getDailyFortune();

}
