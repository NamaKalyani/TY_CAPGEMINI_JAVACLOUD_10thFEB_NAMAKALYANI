package com.tyss.capgemini.spring_demo_annotations;


import org.springframework.stereotype.Component;

@Component
public class DatabaseFotuneService implements FortuneService {

	@Override
	public String getFortune() {
		
		return null;
	}

}
