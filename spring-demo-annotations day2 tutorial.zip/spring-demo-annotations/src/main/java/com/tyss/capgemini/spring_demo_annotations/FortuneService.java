package com.tyss.capgemini.spring_demo_annotations;

public interface FortuneService {
	
	public String getFortune();
}
