package com.tyss.capgemini.spring_demo_annotations;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component

public class TennisCoach implements Coach {
	
	@Autowired
	@Qualifier("randomFortuneService")
	private FortuneService fortuneService;

	// define a default constructor
	public TennisCoach() {
		System.out.println(">> TennisCoach: inside the default Constuctor");
	}

	

	// add init() method
	@PostConstruct
	public void doMyStartupStuff() {
		System.out.println("Tenniscoach: @POSTCONSTRUCT : inside method doMyStartupStuff  ");
	}
	
	// add destroy method
	@PreDestroy
	public void doMyCleanupStuff() {
		System.out.println("Tenniscoach: @PreDestroy:  inside method doMycleanupStuff  ");
	}
	
	
	
	/*
	@Autowired
	public void doSomeCrazyStuff(FortuneService fortuneService) {
		System.out.println(">> TennisCoach: inside the doSomeCrazyStuff()");
		this.fortuneService = fortuneService;
	}

	*/ 


	/*
	// create the constructor in ur class for injections


	@Autowired
	public TennisCoach(FortuneService theFortuneService) {

		fortuneService = theFortuneService;

	}
	 */
	
	@Override
	public String getDailyWorkout() {
		return "practise  your backhand volley";
	}

	@Override
	public String getDailyFortune() {

		return fortuneService.getFortune();
	}



}
