package com.tyss.capgemini.spring_demo_annotations;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class RandomFortuneService implements FortuneService {

	
	// create an array of Strings
	
	private String data[] =
			{
		"be Aware of wolf in sheep clothing ",
		"sun rises in the east" ,
		"The journey is the reward " , 
		"Diligence is the mother of good luck"
			};
	
	// create a random number generator
	private Random myRandom = new Random();
	
	@Override
	public String getFortune() {
		
		// pick a random from the array
		int index = myRandom.nextInt(data.length);
			 
		String theFortune = data[index];
		return theFortune;
	}

}
