package com.tyss.capgemini.spring_demo_annotations;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class AnnotationsDemoApp {

	public static void main(String[] args) {

		// read the spring configuration file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		// get the bean from spring container
		Coach coach = context.getBean("tennisCoach", Coach.class);

		// call methods on the bean
		System.out.println(coach.getDailyWorkout());

		// call our new method for fortunes
		System.out.println(coach.getDailyFortune());

		// close the context
		context.close();
	}
}
