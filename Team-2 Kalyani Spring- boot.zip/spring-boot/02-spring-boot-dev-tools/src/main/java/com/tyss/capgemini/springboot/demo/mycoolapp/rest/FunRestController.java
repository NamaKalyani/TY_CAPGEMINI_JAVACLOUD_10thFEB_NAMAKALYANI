package com.tyss.capgemini.springboot.demo.mycoolapp.rest;

import java.time.LocalDateTime;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FunRestController {
	
	//expose "/" that return the hello world
	
	@GetMapping("/")
	public String sayHello() {
		return "hello world! Time on Server is" +LocalDateTime.now();
		
	}
	//expose a new endpoint for workout
	@GetMapping("/workout")
	public String getDailyWorkout() {
		return "run hard";
	}
	
	//expose a new endpoint for fortune
	@GetMapping("/fortune")
	public String getDailyFortune() {
		return "today is ur lucky day";
	}
	
}
