package com.capgimini.springboot.cruddemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="product")
public class Product {

	//define fields
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="product_name")
	private String productName;
	
	@Column(name="product_url")
	private String productUrl;
	
	@Column(name="product_price")
	private String productPrice;
	
	//define constructor
	
	public Product() {
		
	}

	public Product(String productName, String productUrl, String productPrice) {
		this.productName = productName;
		this.productUrl = productUrl;
		this.productPrice = productPrice;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", productName=" + productName + ", productUrl=" + productUrl + ", productPrice=" + productPrice + "]";
	}

	
}
