package com.capgimini.springboot.cruddemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgimini.springboot.cruddemo.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	//no need of any code ...
}
