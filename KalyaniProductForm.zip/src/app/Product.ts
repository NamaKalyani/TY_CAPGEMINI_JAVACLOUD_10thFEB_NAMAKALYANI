export class Product {
    constructor(
        public productMame: string,
        public productPrice :number,
        public ProductDescription : string,
        public ProductImageUrl: string,
    ){}
}