package com.capgemini;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Driver {

	public static void main(String[] args) {

		try {

			// create object mapper
			ObjectMapper mapper = new ObjectMapper();

			// read JSON file and map/convert to java POJO
			// data/sample-lite.json

			Student theStudent = mapper.readValue(new File("data/sample-full.json"), Student.class);

			// print first name and last name
			System.out.println("First name : " + theStudent.getFirstName());
			System.out.println("Last name : " + theStudent.getLastName());

			//print address: street and city
			Address theAddress = theStudent.getAddress();
			
			System.out.println("Street = "+theAddress.getStreet());
			System.out.println("City = "+theAddress.getCity());
			
			//print the languages
			System.out.print("Languages are : ");
			for(String tempLang : theStudent.getLanguages()) {
				System.out.print(tempLang+","+" ");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
