package com.capgemini;

import lombok.Data;

@Data
public class Address {

	private String Street;
	private String city;
	private String state;
	private String zip;
	private String country;
	
}
