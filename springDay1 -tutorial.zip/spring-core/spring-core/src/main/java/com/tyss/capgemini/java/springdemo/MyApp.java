package com.tyss.capgemini.java.springdemo;

import com.tyss.capgemini.java.springdemo.TrackCoach;

public class MyApp {

	public static void main(String[] args) {
		
		// create the object
		Coach coach = new TrackCoach();
		
		// use the object
		System.out.println(coach.getDailyWorkout());

	}
}
 