package com.tyss.capgemini.java.springdemo;

public class CricketCoach implements Coach {
	private FortuneService fortuneService;
	
	// create the private Fields
	private String emailAddress;
	private String team;
	
	// create setters 
	public void setEmailAddress(String emailAddress) {
		System.out.println("CricketCoach: Inside emailaddress-setEmailAddress" );
		this.emailAddress = emailAddress;
	}


	public String getEmailAddress() {
		return emailAddress;
	}


	public String getTeam() {
		return team;
	}


	public void setTeam(String team) {
		System.out.println("CricketCoach: Inside team-setTeam" );
		this.team = team;
	}
	
	
	
	
	// create no arg- constructor
	
	


	public CricketCoach() {
		System.out.println("CricketCoach: Inside no-arg Constructor" );
	}
	
	
	// our Setter method
	public void setFortuneService(FortuneService fortuneService) {
		System.out.println("CricketCoach: Inside setter mthod-setFortuneService" );
		this.fortuneService = fortuneService;
	}



	@Override
	public String getDailyWorkout() {
		
		return "practise  fast bowling for 15 mintues";
	}

	@Override
	public String getDailyFortune() {
		
		return fortuneService.getFortune();
	}

}
