package com.tyss.capgemini.springdemo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
 
//@Scope("prototype")//it crates new instance every time
@Component
public class TennisCoach implements Coach {
	@Autowired
	@Qualifier("randomFortuneService")
	private FortuneService fortuneService;//field injection
	
	//define default constructor
	public TennisCoach() {
		System.out.println("TennisCoach:Inside default constructor");
		
	}
	
	//define my init method
	@PostConstruct
	public void doMyStartupStuff() {
		System.out.println("TennisCoach:inside of doMyStartupStuff()");
	}
	
	//define destroy method
	@PreDestroy
	public void doMyCleanupStuff() {
		System.out.println("TennisCoach:inside of doMyCleanupStuff()");
	}
//	//1.define setter method
//	@Autowired
//	public void doSomeCrazyStuff(FortuneService theFortuneService) {
//		fortuneService = theFortuneService;
//		System.out.println("TennisCoach:Inside crazy stuff to set");
//	}
//	
	
//	//2.creating constructor for injecting...
//	@Autowired
//	public TennisCoach(FortuneService theFortuneService) {
//		fortuneService = theFortuneService;
//	}
	@Override
	public String getDailyWorkout() {
		return "pracice your backhand volley";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

}
//spring will automatically register this bean
//atSillyCoach")//beanID
//@autowired 3.configuring the dependency