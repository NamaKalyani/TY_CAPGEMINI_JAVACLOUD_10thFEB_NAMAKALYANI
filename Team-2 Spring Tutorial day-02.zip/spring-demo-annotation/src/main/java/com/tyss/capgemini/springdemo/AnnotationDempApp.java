package com.tyss.capgemini.springdemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnnotationDempApp {

	public static void main(String[] args) {
		
		// read spring configaration file
		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//get the bean from spring container
		Coach theCoach = context.getBean("tennisCoach",Coach.class);
		
		//call a methods on the bean
		System.out.println(theCoach.getDailyWorkout());
		
		//call the method to get the daily fortune
		System.out.println(theCoach.getDailyFortune());
		
		//close the context
		context.close();
	}

}

//here tennisCoach is the default bean id