package com.capgemini.springboot.cruddemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springboot.cruddemo.entity.User;
import com.capgemini.springboot.cruddemo.service.UserService;

@RestController
@RequestMapping("/api")
public class UserRestController {

	private UserService userService;

	@Autowired
	public UserRestController(UserService theuserService) {
		userService = theuserService;
	}

	// expose "/users" to return list of students
	@GetMapping("/users")
	public List<User> findAllUsers() {

		return userService.findAllUsers();
	}

	// add mapping for GET /users/{userId}
	@GetMapping("/users/{Id}")
	public User getUser(@PathVariable int id) {

		User user = userService.findUserById(id);

		if (user == null) {
			throw new RuntimeException("User Id not found:" + id);
		}

		return user;
	}

	// add mapping for POST /users - add new user
	@PostMapping("/users")
	public User addUser(@RequestBody User user) {

		// also just in case they pass an id in JSON .... set id to 0
		// this is to force a save of new item .... instead of update
		user.setId(0);

		userService.save(user);

		return user;
	}

	// add mapping for PUT /users - update user
	@PutMapping("/users")
	public User updateUser(@RequestBody User user) {

		userService.save(user);
		return user;
	}

	// add mapping for DELETE /users/{Id} - delete user
	@DeleteMapping("/users/{Id}")
	public String deleteUser(@PathVariable int id) {

		User user = userService.findUserById(id);

		// throw exception if null
		if (user == null) {
			throw new RuntimeException("USer Id not found:" + id);
		}
		userService.deleteById(id);

		return "Deleted User id :" + id;

	}
}
