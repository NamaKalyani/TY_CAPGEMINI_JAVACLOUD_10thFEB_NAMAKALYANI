package com.tyss.capgemini.java.springdemo;

public interface Coach {
	public String getDailyWorkout();
	public String getDailyFortune();
}
