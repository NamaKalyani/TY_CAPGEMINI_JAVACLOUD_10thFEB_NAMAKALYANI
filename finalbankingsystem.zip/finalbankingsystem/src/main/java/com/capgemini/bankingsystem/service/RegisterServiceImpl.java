package com.capgemini.bankingsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bankingsystem.dao.CustomerRepository;
import com.capgemini.bankingsystem.dao.RegisterRepository;
import com.capgemini.bankingsystem.entity.Customer;
import com.capgemini.bankingsystem.entity.Register;

@Service
public class RegisterServiceImpl implements RegisterService {

	private RegisterRepository registerRepository;

	private CustomerRepository customerRepository;

	@Autowired
	public RegisterServiceImpl(RegisterRepository theRegisterRepository, CustomerRepository theCustomerRepository) {
		this.registerRepository = theRegisterRepository;
		this.customerRepository = theCustomerRepository;
	}

	@Override
	public List<Register> findAllUsers() {
		return registerRepository.findAll();
	}

	@Override
	public List<Customer> findAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public Register save(Register register) {
		return registerRepository.save(register);
	}

}
