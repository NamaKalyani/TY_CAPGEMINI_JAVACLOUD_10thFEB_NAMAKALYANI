package com.capgemini.bankingsystem.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bankingsystem.configurer.JwtUtil;
import com.capgemini.bankingsystem.entity.ATM;
import com.capgemini.bankingsystem.entity.Beneficiary;
import com.capgemini.bankingsystem.entity.Customer;
import com.capgemini.bankingsystem.entity.TransactionDetails;
import com.capgemini.bankingsystem.entity.TransferFunds;
import com.capgemini.bankingsystem.exception.CustomerNotFoundException;
import com.capgemini.bankingsystem.exception.EmailNotFoundException;
import com.capgemini.bankingsystem.response.Response;
import com.capgemini.bankingsystem.response.TokenResponse;
import com.capgemini.bankingsystem.service.CustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class CustomerController {

	private CustomerService customerService;

	@Autowired
	public CustomerController(CustomerService thecustomerService) {
		this.customerService = thecustomerService;
	}
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@PostMapping("/login") 
		public TokenResponse<?> generateAuthenticationToken(@RequestBody Customer usersInfo) throws Exception{
		Customer customer = customerService.findByEmail(usersInfo.getEmail());	
		try {
				authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(usersInfo.getEmail(), usersInfo.getPassword()));
			} catch(DisabledException de) {
				//we should use loggers here
//				System.out.println("User is Disabled");
				throw new EmailNotFoundException("USER_DISABLED");
				
			} catch(BadCredentialsException bce) {
				//we should  use loggers here
				throw new EmailNotFoundException("INVALID_CREDENTIALS");
			
			}// End of try catch
			
			
			final UserDetails userDetails = userDetailsService.loadUserByUsername(usersInfo.getEmail());
		
			final String jwt = jwtUtil.generateToken(userDetails);
			
			return new TokenResponse<>(false,"login successfull",jwt, customer);
		}// End of login()
	

	@GetMapping("/get-customers")
	public List<Customer> findAllCustomers() {

		return customerService.findAllCustomers();
	}

	@GetMapping("/customer/{customerId}")
	public Response<Customer> findCustomerById(@PathVariable int customerId) {

		Customer customer = customerService.findCustomerById(customerId);

		if (customer != null) {
			return new Response<Customer>(false, "Customer found", customer);
		} else {
			throw new CustomerNotFoundException("Customer id not found");
		}
	}

	@PostMapping("/add-customer")
	public Response<Customer> saveCustomer(@RequestBody Customer customer) {

//		Customer res = customerService.findByEmail(customer.getEmail());
//		
//		if(res != null) {
//			return new Response<Customer>(true, "This email aleady exists", null);
//		}
//		
//		Customer res1 = customerService.findByPhone(customer.getPhoneNo());
//		
//		Customer res2 = customerService.findByAadhar(customer.getAadharNo());
//		
//		Customer res3 = customerService.findByAccno(customer.getAccNo());

		customer.setCustId(0);
		Customer customer2 = customerService.save(customer);

		if (customer2 != null) {
			return new Response<Customer>(false, "Customer added successfully", customer2);
		} else {
			throw new CustomerNotFoundException("not added");
		}
	}

	@PutMapping("/update-customer")
	public Response<Customer> updateCustomer(@RequestBody Customer customer) {

		Customer customer2 = customerService.save(customer);

		if (customer2 != null) {
			return new Response<Customer>(false, "Customer details updated successfully", customer2);
		} else {
			throw new CustomerNotFoundException("not updated");
		}
	}

	@PostMapping("/atm/{id}")
	public Response<ATM> atm(@PathVariable int id, @RequestBody ATM atm) {

		String atm2 = customerService.atmSimulator(id, atm);

		if (atm2 != null) {
			return new Response<ATM>(false, atm2, null);
		}
		return null;
	}

	@PostMapping("/transfer/{id}")
	public Response<TransferFunds> transferFunds(@PathVariable int id, @RequestBody TransferFunds transferFunds) {

		String transFunds = customerService.transferFunds(id, transferFunds);

		if (transFunds != null) {
			return new Response<TransferFunds>(false, transFunds, null);
		}
		return null;
	}

	@GetMapping("/myTransaction/{id}")
	public List<TransactionDetails> myTransaction(@PathVariable int id) {

		return customerService.myTransaction(id);
	}

	@GetMapping("/myBeneficiary/{id}")
	public List<Beneficiary> myBeneficiary(@PathVariable int id) {

		return customerService.myBeneficiary(id);
	}

	@GetMapping("/customers/{pageNo}/{itemsPerPage}")
	public Page<Customer> getCustomer(@PathVariable int pageNo, @PathVariable int itemsPerPage) {

		return customerService.getCustomers(pageNo, itemsPerPage);
	}

	@GetMapping("/customers/{pageNo}/{itemsPerPage}/{fieldName}")
	public Page<Customer> getSortCustomers(@PathVariable int pageNo, @PathVariable int itemsPerPage,
			@PathVariable String fieldName) {

		return customerService.getSortCustomers(pageNo, itemsPerPage, fieldName);
	}

}
