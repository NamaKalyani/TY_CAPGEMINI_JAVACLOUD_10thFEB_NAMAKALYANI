package com.capgemini.bankingsystem.entity;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class ATM implements Serializable {
	
	@NotNull
	private String amount;
	
	@NotNull
	private String type;
	
	@NotNull
	private String pin;

}
