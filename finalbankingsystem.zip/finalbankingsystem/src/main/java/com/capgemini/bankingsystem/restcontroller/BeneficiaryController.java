package com.capgemini.bankingsystem.restcontroller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bankingsystem.entity.Beneficiary;
import com.capgemini.bankingsystem.exception.AccountNumberNotFoundException;
import com.capgemini.bankingsystem.exception.MessageException;
import com.capgemini.bankingsystem.response.Response;
import com.capgemini.bankingsystem.service.BeneficiaryService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class BeneficiaryController {

	private BeneficiaryService beneficiaryService;

	@Autowired
	public BeneficiaryController(BeneficiaryService theBeneficiaryService) {
		this.beneficiaryService = theBeneficiaryService;
	}

	@GetMapping("/get-beneficiaries")
	public List<Beneficiary> findAllBeneficiaries() {

		return beneficiaryService.findAllBeneficiaries();
	}
	
	@PostMapping("/addBeneficiary/{id}")
	public Response<Beneficiary> addBeneficiary(@PathVariable int id, @Valid @RequestBody Beneficiary beneficiary) {
		beneficiary.setBeneId(0);

		String addBeneficiary = beneficiaryService.addBeneficiary(id, beneficiary);

		if (addBeneficiary != null) {
			return new Response<>(false, addBeneficiary, beneficiary);
		}

		return null;
	}

	@GetMapping("/beneficiary/{id}")
	public Response<Beneficiary> findBeneficiaryById(@PathVariable int id) {

		Beneficiary beneficiary = beneficiaryService.findById(id);

		if (beneficiary != null) {
			return new Response<Beneficiary>(false, "Beneficiary found", beneficiary);
		} else {
			throw new AccountNumberNotFoundException("Beneficiary not found");
		}
	}

	@PostMapping("/add-beneficiary")
	public Response<Beneficiary> addBeneficiary(@RequestBody Beneficiary beneficiary) {

		beneficiary.setBeneId(0);
		Beneficiary beneficiary2 = beneficiaryService.save(beneficiary);

		if (beneficiary2 != null) {
			return new Response<Beneficiary>(false, "Beneficiary added successfully", beneficiary2);
		} else {
			throw new MessageException("Beneficiary not added");
		}
	}

	@DeleteMapping("/delete-beneficiary/{id}")
	public Response<Beneficiary> deleteBeneficiary(@PathVariable int id) {

		Beneficiary beneficiary = beneficiaryService.findById(id);

		if (beneficiary != null) {
			beneficiaryService.deleteById(id);
			return new Response<Beneficiary>(false, "Beneficiary deleted successfully", beneficiary);
		} else {
			throw new MessageException("Not deleted");
		}
	}

	@GetMapping("/beneficiaries/{pageNo}/{itemsPerPage}")
	public Page<Beneficiary> getBeneficiary(@PathVariable int pageNo, @PathVariable int itemsPerPage) {

		return beneficiaryService.getBeneficiaries(pageNo, itemsPerPage);
	}

	@GetMapping("/beneficiaries/{pageNo}/{itemsPerPage}/{fieldName}")
	public Page<Beneficiary> getBeneficiary(@PathVariable int pageNo, @PathVariable int itemsPerPage,
			@PathVariable String fieldName) {

		return beneficiaryService.getBeneficiaries(pageNo, itemsPerPage, fieldName);
	}

}
