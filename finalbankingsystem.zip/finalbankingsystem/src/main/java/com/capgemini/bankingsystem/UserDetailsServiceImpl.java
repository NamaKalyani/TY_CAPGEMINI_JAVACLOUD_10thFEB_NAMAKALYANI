package com.capgemini.bankingsystem;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.capgemini.bankingsystem.service.CustomerService;

@Component
public class UserDetailsServiceImpl implements UserDetailsService{

	@Autowired
	private CustomerService registerService;
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	  
		UserDetailsImpl userDetailsImpl = new UserDetailsImpl();
		
		userDetailsImpl.setUsersInfo(registerService.findByEmail(username));
		
//		userDetailsImpl.setUsersInfo(registerService.);
		
		return userDetailsImpl;
	}

}
