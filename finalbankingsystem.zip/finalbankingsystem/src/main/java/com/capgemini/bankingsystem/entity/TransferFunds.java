package com.capgemini.bankingsystem.entity;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class TransferFunds implements Serializable {
	
	@NotNull
	private String recieverName;
	
	@NotNull
	private String accNo;
	
	@NotNull
	private String amount;
	
	@NotNull
	private String password;

}
