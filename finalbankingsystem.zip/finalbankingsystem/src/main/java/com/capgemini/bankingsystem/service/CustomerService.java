package com.capgemini.bankingsystem.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.capgemini.bankingsystem.entity.ATM;
import com.capgemini.bankingsystem.entity.Beneficiary;
import com.capgemini.bankingsystem.entity.Customer;
import com.capgemini.bankingsystem.entity.TransactionDetails;
import com.capgemini.bankingsystem.entity.TransferFunds;

public interface CustomerService {

	public List<Customer> findAllCustomers();

	public Customer findCustomerById(int id);

	public Customer save(Customer customer);

	public Customer findByEmail(String email);

	public Customer findByAadhar(Long aadhar);

	public Customer findByPhone(Long mobNo);

	public Customer findByAccno(Long accNo);
	
	public List<Beneficiary> myBeneficiary(int id);
	
	public String atmSimulator(int id, ATM atm);
	
	public String transferFunds(int id, TransferFunds transferFunds);
	
	public List<TransactionDetails> myTransaction(int id);

	public Page<Customer> getCustomers(int pageNo, int itemsPerPage);

	public Page<Customer> getSortCustomers(int pageNo, int itemsPerPage, String fieldName);

	

}
