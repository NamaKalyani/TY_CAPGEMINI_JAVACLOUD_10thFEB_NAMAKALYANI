package com.capgemini.bankingsystem.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;

@SuppressWarnings("serial")
@Entity
@Data
@Table(name = "beneficiary_details")
public class Beneficiary implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="bene_id")
	private Integer beneId;

	@Column(name = "first_name")
	@NotNull(message = " please specify first name")
	@Size(min = 3, max = 20)
	@Pattern (regexp = "^[A-Za-z\\s]{4,}[\\.]{0,1}[A-Za-z\\s]{0,}$" , message = "please specify alphabets only and atleast minimum 3 charcters")
	private String firstName;

	@Column(name = "last_name")
	@NotNull(message = " please specify last name")
	@Size(min = 1, max = 20)
	@Pattern (regexp = "^[A-Za-z\\s]{4,}[\\.]{0,1}[A-Za-z\\s]{0,}$" , message = "please specify alphabets only and atleast minimum 1 charcter")
	private String lastName;

	@Column(name = "account_no", unique = true)
	@NotNull(message = "please specify  Account Number")
	@Pattern (regexp ="[0-9]+" , message = "account number accepts number only ")
	private String accno;

	@Column(unique = true)
	@NotNull(message = "please specify email")
	@Pattern(regexp = "^[a-zA-Z0-9_!#$%&â€™*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message ="please specify email only eg:abc@gmail.com")
	private String email;

	@Column(name = "phone_no", unique = true)
	@NotNull(message = "please specify  phone number")
	@Pattern(regexp = "[6-9]{1}[0-9]{9}" , message = " phone number begin with [6-9] and have 10 digits ")
	private String phoneNo;

	@ManyToOne
	@JoinColumn(name = "cust_id")
	@JsonBackReference
	private Customer customer;

}
