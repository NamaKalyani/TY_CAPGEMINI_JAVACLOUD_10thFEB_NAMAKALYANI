package com.capgemini.bankingsystem.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

@SuppressWarnings("serial")
@Entity
@Data
@Table(name ="request")
public class Request implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "request_id")
	@NotNull
	private Integer reqId;
	
	private String address;
	
	@Column(name="phone_number")
	private Long phoneNumber;
	
	private Integer pages;
	
	@Column
	@NotNull
	private String request;
	
	@Column
	@NotNull
	private String status;
}
