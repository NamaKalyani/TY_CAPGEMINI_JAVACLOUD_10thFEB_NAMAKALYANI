package com.capgemini.bankingsystem.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "customer_details")
public class Customer implements Serializable {

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="cust_id")
	private Integer custId;

	@Column(name = "first_name")
	@NotNull(message = " please specify first name")
	@Size(min = 3, max = 20)
	@Pattern (regexp = "^[A-Za-z\\s]{4,}[\\.]{0,1}[A-Za-z\\s]{0,}$" , message = "please specify alphabets only and atleast minimum 3 charcters")
	private String firstName;
	

	@Column(name = "last_name")
	@NotNull(message = " please specify last name")
	@Size(min = 1, max = 20)
	@Pattern (regexp = "^[A-Za-z\\s]{4,}[\\.]{0,1}[A-Za-z\\s]{0,}$" , message = "please specify alphabets only and atleast minimum 1 charcter")
	private String lastName;

	@Column
	@Pattern(regexp = "^(?:others|male|female)" , message = "please specify gender from (male/female/others)")
	@NotNull(message = "please specify gender")
	private String gender;

	@Column(name = "dob")
	@NotNull(message = "please specify Date-Of-Birth")
	private String dob;

	@Column(name = "aadhar_no", unique = true)
	@NotNull (message = "please specify aadhar number")
	@Size(max = 12)
	@Pattern(regexp = "[0-9]{12}",message =" Aadhar Number should contain only 12 numbers")
	private String aadharNo;

	@Column(unique = true)
	@NotNull(message = "please specify email")
	//@Pattern(regexp = "^[a-zA-Z0-9_!#$%&â€™*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message ="please specify email only eg:abc@gmail.com")
	private String email;

	
	@Column(name = "phone_no", unique = true)
	@NotNull(message = "please specify  phone number")
	@Pattern(regexp = "[6-9]{1}[0-9]{9}" , message = " phone number begin with [6-9] and have 10 digits ")
	private String phoneNo;

	@Column
	@Size(min = 3, max = 150)
	@NotNull(message = "please specify  address")
	private String address;

	@Column(name = "account_no", unique = true)
	@NotNull(message = "please specify  Account Number")
	@Pattern (regexp ="[0-9]+" , message = "account number accepts number only ")
	private String accno;

	@Column(name = "bank_branch")
	@NotNull (message = "please specify  bank branch")
	private String bankBranch;
	
	
	@Column(name = "opening_balance")
	@NotNull(message = "please specify  balance")
	private   String  balance;

	@Column
	@NotNull(message = "please specify  Pin")
	@Pattern(regexp ="^[0-9]{4}$" ,message = "please specify 4 digits only")
	private String  pin;

	@Column(name = "user_name")
	@NotNull(message = " Username is required")
	private String userName;

	@Column
	@NotNull(message = "please specify password")
//	@Pattern(regexp = "(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" , message ="password should contains atleast 8 charcters, one uppercase, lowercase, special symbol")
	private String password;
	
	@Column
	@NotNull(message = "please specify role eg : ROLE_XXXX")
	private String role;

	
	@OneToMany(mappedBy = "customer",cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<Beneficiary> beneficiaryList;
	
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<TransactionDetails> transcationDetailsList;
	

	public Integer getCustId() {
		return custId;
	}



}
