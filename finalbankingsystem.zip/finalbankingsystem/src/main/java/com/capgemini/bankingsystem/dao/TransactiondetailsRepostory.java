package com.capgemini.bankingsystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bankingsystem.entity.TransactionDetails;

@Repository
public interface TransactiondetailsRepostory extends JpaRepository<TransactionDetails, Integer> {

}
