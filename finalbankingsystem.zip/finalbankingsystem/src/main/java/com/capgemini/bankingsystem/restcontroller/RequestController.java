package com.capgemini.bankingsystem.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bankingsystem.entity.Request;
import com.capgemini.bankingsystem.exception.MessageException;
import com.capgemini.bankingsystem.response.Response;
import com.capgemini.bankingsystem.service.RequestService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class RequestController {

	private RequestService requestService;

	@Autowired
	public RequestController(RequestService theRequestService) {
		this.requestService = theRequestService;
	}

	@GetMapping("/requests")
	public List<Request> findAllRequests() {
		return requestService.findAllRequests();
	}

	@GetMapping("/requests/{reqId}")
	public Response<Request> findById(@PathVariable int reqId) {

		Request request = requestService.findById(reqId);

		if (request != null) {
			return new Response<Request>(false, "RequestId found", request);
		} else {
			throw new MessageException("Request Id not found");
		}
	}

	@PostMapping("/addRequest")
	public Response<Request> addRequest(@RequestBody Request request) {

		request.setReqId(0);

		Request request2 = requestService.save(request);

		if (request2 != null) {
			return new Response<Request>(false, "Request sent successfully", request);
		} else {
			throw new MessageException("Request not sent");
		}
	}
	
	@PutMapping("/updateRequest")
	public Response<Request> updateRequest(@RequestBody Request request) {

		Request request2 = requestService.save(request);

		if (request2 != null) {
			return new Response<Request>(false, "Request updated successfully", request);
		} else {
			throw new MessageException("Request not updated");
		}
	}

}
