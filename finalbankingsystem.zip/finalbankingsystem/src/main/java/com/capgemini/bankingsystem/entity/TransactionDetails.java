package com.capgemini.bankingsystem.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name ="transactions")
public class TransactionDetails implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="trans_id")
	private Integer transId;
	
	@Column(name="date_and_time")
	private Date date;
	
	@Column
	private String remarks;
	
	@Column
	private String credit;
	
	@Column
	private String debit;
	
	@Column
	private String balance;
	
	@Column
	private String id;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cust_id")
	@JsonBackReference
	private Customer customer;

}
