package com.capgemini.bankingsystem.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bankingsystem.entity.TransactionDetails;
import com.capgemini.bankingsystem.service.TransactionService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class TransactionController {

	private TransactionService transactionService;

	@Autowired
	public TransactionController(TransactionService theTransactionService) {
		this.transactionService = theTransactionService;
	}

	@GetMapping("/allTransactions")
	public List<TransactionDetails> findAllTranscations() {
		
		return transactionService.findAllTransaction();
	}

}
