package com.capgemini.bankingsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bankingsystem.dao.TransactiondetailsRepostory;
import com.capgemini.bankingsystem.entity.TransactionDetails;

@Service
public class TransactionServiceImpl implements TransactionService {

	private TransactiondetailsRepostory transactiondetailsRepository;

	@Autowired
	public TransactionServiceImpl(TransactiondetailsRepostory theTransactiondetailsRepository) {
		this.transactiondetailsRepository = theTransactiondetailsRepository;
	}

	@Override
	public List<TransactionDetails> findAllTransaction() {

		return transactiondetailsRepository.findAll();
	}

}
