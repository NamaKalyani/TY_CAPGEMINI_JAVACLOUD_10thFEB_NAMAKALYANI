package com.capgemini.bankingsystem.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.capgemini.bankingsystem.dao.CustomerRepository;
import com.capgemini.bankingsystem.dao.TransactiondetailsRepostory;
import com.capgemini.bankingsystem.entity.ATM;
import com.capgemini.bankingsystem.entity.Beneficiary;
import com.capgemini.bankingsystem.entity.Customer;
import com.capgemini.bankingsystem.entity.TransactionDetails;
import com.capgemini.bankingsystem.entity.TransferFunds;
import com.capgemini.bankingsystem.exception.EmailNotFoundException;

@Service
public class CustomerServiceImpl implements CustomerService {

	private CustomerRepository customerRepository;

//	private TransactiondetailsRepostory transactiondetailsRepostory;

	@Autowired
	public CustomerServiceImpl(CustomerRepository theCustomerRepository) {
		this.customerRepository = theCustomerRepository;
//		this.transactiondetailsRepostory = theTransactiondetailsRepostory;
	}

	@Override
	public List<Customer> findAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public Customer findCustomerById(int id) {
		Optional<Customer> result = customerRepository.findById(id);

		Customer customer = null;
		if (result.isPresent()) {
			customer = result.get();
		}

		return customer;
	}

	@Override
	public Customer save(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public Page<Customer> getCustomers(int pageNo, int itemsPerPage) {

		Pageable pageable = PageRequest.of(pageNo, itemsPerPage);
		return customerRepository.findAll(pageable);

	}

	@Override
	public Page<Customer> getSortCustomers(int pageNo, int itemsPerPage, String fieldName) {

		Pageable pageable = PageRequest.of(pageNo, itemsPerPage, Sort.by(fieldName));
		return customerRepository.findAll(pageable);
	}

	@Override
	public Customer findByEmail(String email) {

		Customer customer = customerRepository.findbyEmail(email);
		if(customer == null) {
			throw new EmailNotFoundException("Invalid Email");
		}
		return customer;
	}

	@Override
	public Customer findByAadhar(Long aadhar) {

		return customerRepository.findbyAadhar(aadhar);
	}

	@Override
	public Customer findByPhone(Long mobNo) {

		return customerRepository.findbyMobile(mobNo);
	}

	@Override
	public Customer findByAccno(Long accNo) {

		return customerRepository.findbyAccNo(accNo);
	}

	@Override
	public String atmSimulator(int id, ATM atm) {

		String message = "";

		Customer customer = customerRepository.findById(id).get();

		if (customer != null) {

			double balance = Double.parseDouble(customer.getBalance());
			double withdraw = Double.parseDouble(atm.getAmount());

			if (balance > withdraw) {

				if (atm.getPin().equals(customer.getPin())) {

					List<TransactionDetails> transaction = new ArrayList<TransactionDetails>();
					balance = balance - withdraw;

					customer.setBalance(balance + "");

					TransactionDetails transferDetails = new TransactionDetails();
					transferDetails.setDebit(withdraw + "");
					transferDetails.setCredit(0.00 + "");
					transferDetails.setBalance(balance + "");
					transferDetails.setDate(new Date());
					transferDetails.setRemarks("Withdrawn By ATM");
					transferDetails.setId(customer.getCustId() + "");
					transferDetails.setCustomer(customer);

					transaction.add(transferDetails);

					customer.setTranscationDetailsList(transaction);

					customerRepository.save(customer);

					message = "Transcation Successfull";
				} else {
					message = "Wrong pin";
				}
			} else {
				message = "Don't have sufficient balance";
			}
		} else {
			message = "Id not found";
		}

		return message;
	}
	@Override
	public String transferFunds(int id, TransferFunds transferFunds) {

		String message = "";

		Customer customer = customerRepository.findById(id).get();

		if (customer != null) {

			boolean result = false;

			for (Beneficiary beneficiary : customer.getBeneficiaryList()) {

				if (transferFunds.getAccNo() .equals( beneficiary.getAccno())){
					result = true;
				} else {
					message = "Invalid Account number";
				}
			}

			
			if (result) {
				double balance = Double.parseDouble(customer.getBalance());

				double transAmount = Double.parseDouble(transferFunds.getAmount());

				if (balance > transAmount) {

					if (transferFunds.getPassword().equals(customer.getPassword())) {

						List<TransactionDetails> transaction = new ArrayList<TransactionDetails>();
						balance = balance - transAmount;

						customer.setBalance(balance + "");

						TransactionDetails transferDetails = new TransactionDetails();
						transferDetails.setDebit(transAmount+ "");
						transferDetails.setCredit(0.00+ "");
						transferDetails.setBalance(balance+ "");
						transferDetails.setDate(new Date());
						transferDetails.setId("Transaction Done by Customer Id: " + customer.getCustId());
						transferDetails.setRemarks("Transfer to Beneficiary, ACC.NO:" + transferFunds.getAccNo());
						transferDetails.setCustomer(customer);

						transaction.add(transferDetails);

						customer.setTranscationDetailsList(transaction);

						customerRepository.save(customer);

					} else {
						message = "Incorrect Password";
					}

				} else {
					message = "Dont have sufficient balance";
				}
			}
		}

		return message;
	}

	@Override
	public List<TransactionDetails> myTransaction(int id) {

		Customer customer = customerRepository.findById(id).get();

//		return transactiondetailsRepostory.findAll().stream()
//				.filter(customer1 -> customer1.getCustomer().getCustId() == id).collect(Collectors.toList());
		if (customer != null) {
			return customer.getTranscationDetailsList();
		}
		return null;
	}

	@Override
	public List<Beneficiary> myBeneficiary(int id) {

		Customer customer = customerRepository.findById(id).get();

		if (customer != null) {
			return customer.getBeneficiaryList();
		}

		return null;
	}

}
