package com.capgemini.bankingsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.capgemini.bankingsystem.dao.BeneficiaryRepository;
import com.capgemini.bankingsystem.dao.CustomerRepository;
import com.capgemini.bankingsystem.entity.Beneficiary;
import com.capgemini.bankingsystem.entity.Customer;

@Service
public class BeneficiaryServiceImpl implements BeneficiaryService {

	private BeneficiaryRepository beneficiaryRepository;

	private CustomerRepository customerRepository;

	@Autowired
	public BeneficiaryServiceImpl(BeneficiaryRepository theBeneficiaryRepository,
			CustomerRepository theCustomerRepository) {
		this.beneficiaryRepository = theBeneficiaryRepository;
		this.customerRepository = theCustomerRepository;
	}

	@Override
	public List<Beneficiary> findAllBeneficiaries() {

		return beneficiaryRepository.findAll();
	}

	@Override
	public String addBeneficiary(int id, Beneficiary beneficiary) {

		String message = "";
		Customer customer = customerRepository.findById(id).get();

		if (customer == null) {
			message = "Customer not found";
			return message;
		} else {
			beneficiary.setCustomer(customer);

			beneficiaryRepository.save(beneficiary);
			message = "Beneficiary added Successfully";
		}
		return message;
	}

	@Override
	public Beneficiary save(Beneficiary beneficiary) {

		return beneficiaryRepository.save(beneficiary);
	}

	@Override
	public Beneficiary findById(int id) {

		Optional<Beneficiary> result = beneficiaryRepository.findById(id);

		Beneficiary beneficiary = null;
		if (result.isPresent()) {
			beneficiary = result.get();
		}

		return beneficiary;
	}

	@Override
	public void deleteById(int id) {
		beneficiaryRepository.deleteById(id);
	}

	@Override
	public Page<Beneficiary> getBeneficiaries(int pageNo, int itemsPerPage) {

		Pageable pageable = PageRequest.of(pageNo, itemsPerPage);
		return beneficiaryRepository.findAll(pageable);
	}

	@Override
	public Page<Beneficiary> getBeneficiaries(int pageNo, int itemsPerPage, String fieldName) {

		Pageable pageable = PageRequest.of(pageNo, itemsPerPage, Sort.by(fieldName));
		return beneficiaryRepository.findAll(pageable);
	}

}
