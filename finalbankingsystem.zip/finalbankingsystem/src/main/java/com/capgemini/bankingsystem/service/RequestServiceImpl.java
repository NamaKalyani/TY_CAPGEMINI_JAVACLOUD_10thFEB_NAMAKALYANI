package com.capgemini.bankingsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bankingsystem.dao.RequestRepository;
import com.capgemini.bankingsystem.entity.Request;

@Service
public class RequestServiceImpl implements RequestService {

	private RequestRepository requestRepository;

	@Autowired
	public RequestServiceImpl(RequestRepository theRequestRepository) {
		this.requestRepository = theRequestRepository;
	}

	@Override
	public List<Request> findAllRequests() {

		return requestRepository.findAll();
	}

	@Override
	public Request findById(int id) {

		Optional<Request> result = requestRepository.findById(id);

		Request request = null;
		if (result.isPresent()) {
			request = result.get();
		}

		return request;
	}

	@Override
	public Request save(Request request) {

		return requestRepository.save(request);
	}

}
