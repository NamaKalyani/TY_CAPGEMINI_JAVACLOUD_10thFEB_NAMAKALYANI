package com.capgemini.bankingsystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.bankingsystem.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	
	@Query("from Customer where email=?1")
	Customer findbyEmail(String email);
	
	@Query("from Customer where phone_number=?1")
	Customer findbyMobile(Long mobNo);
	
	@Query("from Customer where aadhar_number=?1")
	Customer findbyAadhar(Long aadhar);
	
	@Query("from Customer where account_number=?1")
	Customer findbyAccNo(Long accNo);
	
}
