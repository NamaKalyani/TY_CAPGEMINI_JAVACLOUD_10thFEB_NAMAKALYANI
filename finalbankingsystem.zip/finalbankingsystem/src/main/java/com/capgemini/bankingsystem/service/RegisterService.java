package com.capgemini.bankingsystem.service;

import java.util.List;

import com.capgemini.bankingsystem.entity.Customer;
import com.capgemini.bankingsystem.entity.Register;

public interface RegisterService {
	
	public List<Register> findAllUsers();
	
	public List<Customer> findAllCustomers();
	
	public Register save(Register register);

}
