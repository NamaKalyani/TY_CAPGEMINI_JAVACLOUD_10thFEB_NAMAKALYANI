package com.capgemini.bankingsystem.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.capgemini.bankingsystem.entity.Beneficiary;

public interface BeneficiaryService {
	
	public List<Beneficiary> findAllBeneficiaries();
	
	public Beneficiary save(Beneficiary beneficiary);
	
	public Beneficiary findById(int id);
	
	public void deleteById(int id);
	
	public Page<Beneficiary> getBeneficiaries(int pageNo, int itemsPerPage);
	
	public Page<Beneficiary> getBeneficiaries(int pageNo, int itemsPerPage, String fieldName);

	String addBeneficiary(int id, Beneficiary beneficiary);

}
