package com.capgemini.bankingsystem.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bankingsystem.entity.Customer;
import com.capgemini.bankingsystem.entity.Register;
import com.capgemini.bankingsystem.exception.MessageException;
import com.capgemini.bankingsystem.response.Response;
import com.capgemini.bankingsystem.service.RegisterService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class RegisterController {

	private RegisterService registerService;

	@Autowired
	public RegisterController(RegisterService theRegisterService) {
		this.registerService = theRegisterService;
	}
	
	@GetMapping("/users")
	public List<Register> findAllUsers(){
		return registerService.findAllUsers();
	}
	
	@GetMapping("/getCustomers")
	public List<Customer> findAllCustomers(){
		return registerService.findAllCustomers();
	}
	
	@PostMapping("/addUser")
	public Response<Register> addUser(@RequestBody Register register){
		
		Register register2 = registerService.save(register);
		
		if(register2 != null) {
			return new Response<Register>(false, "Added Successfully", null);
		} else {
			throw new MessageException("not added");
		}
	}
	
	

}
