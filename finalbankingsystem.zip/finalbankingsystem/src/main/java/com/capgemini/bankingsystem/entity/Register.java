package com.capgemini.bankingsystem.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "register")
public class Register implements Serializable {
	
	@Column(name="full_name")
	@NotNull
	private String fullName;
	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@NotNull
	private String email;
	
	@NotNull
	private String password;
	
	@NotNull
	private String role;

}
