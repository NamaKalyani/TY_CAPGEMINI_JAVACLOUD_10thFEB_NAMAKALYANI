package com.capgemini.bankingsystem;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringBootSecurityApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

}
