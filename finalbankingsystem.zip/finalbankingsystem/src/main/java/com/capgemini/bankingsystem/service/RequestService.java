package com.capgemini.bankingsystem.service;

import java.util.List;

import com.capgemini.bankingsystem.entity.Request;

public interface RequestService {

	public List<Request> findAllRequests();

	public Request findById(int id);

	public Request save(Request request);
	
}
