package com.capgemini.bankingsystem.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.capgemini.bankingsystem.entity.Customer;
import com.capgemini.bankingsystem.response.Response;
import com.capgemini.bankingsystem.response.TokenResponse;

@ControllerAdvice
public class GenericException {

	@ExceptionHandler
	public ResponseEntity<Response<Customer>> handleException(CustomerNotFoundException exception) {
		
		Response<Customer> response = new Response<>(true, exception.getMessage(), null);
		
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler
	public ResponseEntity<Response<Customer>> handleException(AccountNumberNotFoundException exception) {
		
		Response<Customer> response = new Response<>(true, exception.getMessage(), null);
		
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler
	public ResponseEntity<Response<Customer>> handleException(MessageException exception) {
		
		Response<Customer> response = new Response<>(true, exception.getMessage(), null);
		
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler
	public ResponseEntity<TokenResponse<Customer>> handleException(EmailNotFoundException exception) {
		
		TokenResponse<Customer> response = new TokenResponse<>(true, exception.getMessage(), null ,null);
		
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}
	
	

}
