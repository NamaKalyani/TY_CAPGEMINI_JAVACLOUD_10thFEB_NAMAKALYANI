package com.capgemini.bankingsystem.service;

import java.util.List;

import com.capgemini.bankingsystem.entity.TransactionDetails;

public interface TransactionService {
	
	public List<TransactionDetails> findAllTransaction();
}
