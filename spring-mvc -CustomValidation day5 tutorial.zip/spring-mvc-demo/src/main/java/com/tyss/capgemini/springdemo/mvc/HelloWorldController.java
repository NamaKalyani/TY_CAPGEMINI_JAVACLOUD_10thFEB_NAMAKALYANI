package com.tyss.capgemini.springdemo.mvc;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("hello")
public class HelloWorldController {
	
	// need a controller method to show the intial HTML form
	@RequestMapping("/showForm")
	public String showForm() {
		return "helloworld-form";
	}
	
	// need a controller method to process the html form
	@RequestMapping("/processForm")
	public String processForm() {
		return "helloworld";
	}
	
	// new a Controller method to read from data
	@RequestMapping("/processFormVersionTwo")
	public String letschillbro(HttpServletRequest request , Model model  ) {
		
		// Read the request parameter from html form
		String name = request.getParameter("studentName");
		
		// Convert the all data into all Capital letters
			 name = name.toUpperCase();
		// Create the message 
		String result ="Yo**Yo@Yo--$Yoo   " + name;
		
		// add the message to the model
		
		model.addAttribute("msg" ,result);
		return "helloworld";
		
		
	}
	
	@RequestMapping("/processFormVersionThree")
	public String processFormVersionThree(@RequestParam("studentName") String name ,
								Model model  ) {
		
		
		
		// Convert the all data into all Capital letters
			 name = name.toUpperCase();
		// Create the message 
		String result ="  Hlo Bro How Are You?????? from v3   " + name;
		
		// add the message to the model
		
		model.addAttribute("msg" ,result);
		return "helloworld";
		
		
	}
	
	
	
	
	
}
