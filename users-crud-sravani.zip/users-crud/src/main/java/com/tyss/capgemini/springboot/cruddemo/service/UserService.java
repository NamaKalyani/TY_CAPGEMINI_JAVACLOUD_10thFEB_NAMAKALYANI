package com.tyss.capgemini.springboot.cruddemo.service;

import java.util.List;

import com.tyss.capgemini.springboot.cruddemo.entity.User;

public interface UserService {
	
public List<User> findAll();
	
	public User findById(int theId);
	
	public void save(User theUser);
	
	public void deleteById(int theId);
}
