package com.capgemini.springdemo.mvc;

import java.util.LinkedHashMap;

import lombok.Data;

@Data
public class Student {
	private String firstName;
	private String lastName;
	private String country;
	
	private LinkedHashMap<String, String> countryOptions;
	
	private String favoriteLanguage;
	
	private String operatingSystems;

	public  Student() {
		// populate country options : used ISO country code
		countryOptions = new LinkedHashMap<String, String>();
		countryOptions.put("IND", "INDIA");
		countryOptions.put("USA", "AMERCIA");
		countryOptions.put("FR", "FRANCE");
		countryOptions.put("NY", "NEWYORK");
		countryOptions.put("DE", "GERMANY");

	}

}
