package com.capgemini.springdemo.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springdemo.entity.Student;

@RestController
@RequestMapping("/api")
public class StudentRestController {

	// define end point for "/students" - return a list of students
	@GetMapping("/students")
	public List<Student> getStudents() {

		List<Student> list = new ArrayList<Student>();

		list.add(new Student("Nandha", "kumar"));
		list.add(new Student("Ram", "kumar"));
		list.add(new Student("Naga", "Arjun"));
		list.add(new Student("Naveen", "kumar"));
		
		return list;
	}
	
	// define end point for "/students/{studentId}" - return student at index
	@GetMapping("/students/{studentId}")
	public Student getStudent(@PathVariable int studentId) {
		
		//just index into list
		
//		return list.get(studentId);
		return null;
		
	}
}