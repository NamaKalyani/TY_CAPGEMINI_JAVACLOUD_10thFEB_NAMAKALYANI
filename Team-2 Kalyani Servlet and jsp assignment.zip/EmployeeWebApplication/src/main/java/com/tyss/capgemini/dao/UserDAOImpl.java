package com.tyss.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tyss.capgemini.beans.User;
import com.tyss.capgemini.util.DatabaseConnectionutil;

public class UserDAOImpl implements UserDAO {

	Connection connection = null;
	ResultSet resultSet = null;
	Statement statement = null;
	PreparedStatement preparedStatement = null;

	@Override
	public List<User> get() {

		List<User> list = null;
		User user = null;

		try {

			list = new ArrayList<User>();
			// create sql query
			String sql = "SELECT * FROM tbl_user";
			// get database connection
			connection = DatabaseConnectionutil.openConnection();
			// create the statement
			statement = connection.createStatement();
			// execute the sql query
			resultSet = statement.executeQuery(sql);
			// process the resultSet
			while (resultSet.next()) {
				user = new User();
				user.setId(resultSet.getInt("id"));
				user.setName(resultSet.getString("name"));
				user.setPassword(resultSet.getString("password"));
				user.setEmail(resultSet.getString("email"));
				user.setSex(resultSet.getString("sex"));
				user.setCountry(resultSet.getString("country"));
				list.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// execute the list
		return list;

	}

	@Override
	public boolean save(User user) {

		boolean flag = false;
		try {
			String sql = "INSERT INTO tbl_user(name, password, email, sex, country)VALUES" + "('" + user.getName()
					+ "', '" + user.getPassword() + "', '" + user.getEmail() + "', '" + user.getSex() + "', '"
					+ user.getCountry() + "')";
			connection = DatabaseConnectionutil.openConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			flag = true;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return flag;
	}

	@Override
	public User get(int id) {
		User user = null;
		try {
			user = new User();
			String sql = "SELECT * FROM tbl_user where id="+id;
			connection = DatabaseConnectionutil.openConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next()) {
				user.setId(resultSet.getInt("id"));
				user.setName(resultSet.getString("name"));
				user.setEmail(resultSet.getString("email"));
				user.setPassword(resultSet.getString("password"));
				user.setSex(resultSet.getString("sex"));
				user.setCountry(resultSet.getString("country"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return user;

	}

	@Override
	public boolean update(User user) {
		
		boolean flag = false;
		try {
			String sql = "UPDATE tbl_user SET name = '"+user.getName()+"', "
					+ "password = '"+user.getPassword()+"', email = '"+user.getEmail()+"' where id="+user.getId();
			connection = DatabaseConnectionutil.openConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			flag = true;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}


	@Override
	public boolean delete(int id) {
		
		boolean flag = false;
		try {
			String sql = "DELETE FROM tbl_user where id="+id;
			connection = DatabaseConnectionutil.openConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			flag = true;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return flag;

	}

}