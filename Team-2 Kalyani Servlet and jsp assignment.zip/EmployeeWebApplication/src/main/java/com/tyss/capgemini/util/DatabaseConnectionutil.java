package com.tyss.capgemini.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnectionutil {
	
	// define DB properties
		private static final String userName = "root";
		private static final String password = "root";
		private static final String jdbcURL = "jdbc:mysql://localhost:3306/employeedirectory";
		private static final String driver = "com.mysql.jdbc.Driver";
		private static Connection connection = null;
		
		//get the database connection
		public static Connection openConnection() {
			//checking connection
			if (connection != null) {
				return connection;
			} else {
				try {
					Class.forName(driver);// Loading the diver
					connection = DriverManager.getConnection(jdbcURL, userName, password);// getting the connection
				} catch (Exception e) {
					e.printStackTrace();
				}
				return connection;
			}

		}

}
