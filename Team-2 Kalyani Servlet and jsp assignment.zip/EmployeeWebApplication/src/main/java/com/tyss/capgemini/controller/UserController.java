package com.tyss.capgemini.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tyss.capgemini.beans.User;
import com.tyss.capgemini.dao.UserDAO;
import com.tyss.capgemini.dao.UserDAOImpl;

public class UserController extends HttpServlet {

	UserDAO userDAO = null;
	RequestDispatcher requestDispatcher = null;

	public UserController() {
		userDAO = new UserDAOImpl();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");

		if (action == null) {
			action = "LIST";
		}
		switch (action) {

		case "LIST":
			listUser(req, resp);
			break;
			
		case "EDIT":
			getSingleUser(req,resp);
			break;
			
		case "DELETE":
			deleteUser(req,resp);
			break;

		default:
			listUser(req, resp);
			break;
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		
		User user = new User();
		user.setName(req.getParameter("firstname"));
		user.setPassword(req.getParameter("password"));
		user.setEmail(req.getParameter("email"));
		user.setSex(req.getParameter("sex"));
		user.setCountry(req.getParameter("country"));
		
		if(id.isEmpty() || id == null) {
			//Add User
			if(userDAO.save(user)) {
				req.setAttribute("message", "User Added Successfully");
				
			}
			
		}else {
			//update user
			user.setId(Integer.parseInt(id));
			if(userDAO.update(user)) {
				req.setAttribute("message", "Use Updated Successfully");
			}
		}
		listUser(req,resp);
	}

	private void listUser(HttpServletRequest req, HttpServletResponse resp)throws ServletException,IOException
	{
		List<User> list = userDAO.get();
		req.setAttribute("list", list);
		requestDispatcher = req.getRequestDispatcher("/views/user-list.jsp");
		requestDispatcher.forward(req, resp);

	}
	
	private void getSingleUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		
		String id = req.getParameter("id");
		User user = userDAO.get(Integer.parseInt(id));
		req.setAttribute("user", user);
		requestDispatcher = req.getRequestDispatcher("/views/user-add.jsp");
		requestDispatcher.forward(req, resp);
	}
	

	private void deleteUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException {
	String id = req.getParameter("id");
	if(userDAO.delete(Integer.parseInt(id))) {
		req.setAttribute("message", "User deleted");
	}
	listUser(req,resp);
		
	}
	
	

}
