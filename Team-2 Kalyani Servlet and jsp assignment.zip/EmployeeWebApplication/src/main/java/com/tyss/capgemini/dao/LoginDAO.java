package com.tyss.capgemini.dao;

import com.tyss.capgemini.beans.Login;

public interface LoginDAO {
	String authenticate(Login login);

	
}
