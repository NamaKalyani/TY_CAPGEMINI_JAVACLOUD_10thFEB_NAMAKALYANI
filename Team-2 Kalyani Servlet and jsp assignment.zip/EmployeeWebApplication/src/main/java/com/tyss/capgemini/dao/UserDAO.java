package com.tyss.capgemini.dao;

import java.util.List;

import com.tyss.capgemini.beans.User;

public interface UserDAO {
	List<User>get();
	
	boolean save(User user);
	
	User get(int id);
	
	boolean update(User user);
	
	boolean delete(int id);

}
