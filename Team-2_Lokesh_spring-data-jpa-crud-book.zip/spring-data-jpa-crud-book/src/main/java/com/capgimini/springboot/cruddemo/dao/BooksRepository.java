package com.capgimini.springboot.cruddemo.dao;
import org.springframework.data.repository.CrudRepository;
//repository that extends CrudRepository
import com.capgimini.springboot.cruddemo.entity.Books;
public interface BooksRepository extends CrudRepository<Books, Integer>
{
}
