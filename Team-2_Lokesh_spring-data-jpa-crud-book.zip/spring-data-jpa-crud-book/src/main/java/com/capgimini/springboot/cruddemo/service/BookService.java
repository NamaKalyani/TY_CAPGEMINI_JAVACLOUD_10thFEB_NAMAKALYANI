package com.capgimini.springboot.cruddemo.service;

import java.util.List;

import com.capgimini.springboot.cruddemo.entity.Books;

public interface BookService {

	public List<Books> getAllBooks();

	public Books getBooksById(int id);

	public void saveOrUpdate(Books books);

	public void delete(int id);
	
	public void update(Books books, int bookid);
}
