package com.tyss.capgemini.springboot.cruddemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tyss.capgemini.springboot.cruddemo.entity.Book;
import com.tyss.capgemini.springboot.cruddemo.service.BookService;

@RestController
@RequestMapping("/api")
public class BookRestController {

	private BookService bookService;

	@Autowired
	public BookRestController(BookService theEmployeeService) {
		bookService = theEmployeeService ;
	}

	// expose "/employees" and return list of employees
	@GetMapping("/books")
	public List<Book> findAll() {
		return bookService.findAll();
	}

	
	// add mapping for POST /book - add new book

	@PostMapping("/books")
	public Book addBook(@RequestBody Book theBook) {

		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update

		theBook.setId(0);

		bookService.save(theBook);

		return theBook;
	}

	// add mapping for PUT /employees - update existing employee
	
		@PutMapping("/books")
		public Book updateBook(@RequestBody Book theBook) {
			
			bookService.save(theBook);
			
			return theBook;
		}
		
}
