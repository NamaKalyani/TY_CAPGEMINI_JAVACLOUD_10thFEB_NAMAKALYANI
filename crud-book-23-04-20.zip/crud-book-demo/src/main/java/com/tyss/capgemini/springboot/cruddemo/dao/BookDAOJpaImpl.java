package com.tyss.capgemini.springboot.cruddemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tyss.capgemini.springboot.cruddemo.entity.Book;


@Repository
 public class BookDAOJpaImpl implements BookDAO {

	private EntityManager entityManager;
	
	@Autowired
	public BookDAOJpaImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}
	
	@Override
	public List<Book> findAll() {
		// create a query
		Query theQuery = 
				entityManager.createQuery("from Book");
		
		// execute query and get result list
		List<Book> books = theQuery.getResultList();
		
		// return the results		
		return books;
	}

	@Override
	public void save(Book theBook) {

		// save or update the employee
		Book dbBook = entityManager.merge(theBook);
		
		// update with id from db ... so we can get generated id for save/insert
		theBook.setId(dbBook.getId());
		
	}

	

}
