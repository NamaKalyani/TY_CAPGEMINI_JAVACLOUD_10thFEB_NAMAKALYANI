package com.tyss.capgemini.springboot.cruddemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tyss.capgemini.springboot.cruddemo.dao.BookDAO;
import com.tyss.capgemini.springboot.cruddemo.entity.Book;

@Service
public class BookServiceImpl implements BookService {
	
private BookDAO bookDAO;
	
	@Autowired
	public BookServiceImpl(@Qualifier("bookDAOJpaImpl")BookDAO thebookDAO) {
		bookDAO = thebookDAO;
	}
	
	@Override
	@Transactional
	public List<Book> findAll() {
		return bookDAO.findAll();
	}


	@Override
	@Transactional
	public void save(Book theEmployee) {
		bookDAO.save(theEmployee);
	}

	
}
