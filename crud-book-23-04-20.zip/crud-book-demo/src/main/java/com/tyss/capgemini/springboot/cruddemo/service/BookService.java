package com.tyss.capgemini.springboot.cruddemo.service;

import java.util.List;

import com.tyss.capgemini.springboot.cruddemo.entity.Book;

public interface BookService {
	
public List<Book> findAll();
	
	public void save(Book theBook);
	
	
}
