package com.tyss.capgemini.springboot.cruddemo.dao;

import java.util.List;

import com.tyss.capgemini.springboot.cruddemo.entity.Book;

public interface BookDAO {
	
	public List<Book> findAll();
	
	public void save(Book theEmployee);
	
	}
