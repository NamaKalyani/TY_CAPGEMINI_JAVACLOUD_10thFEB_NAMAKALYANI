package com.tyss.capgemini.springboot.cruddemo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tyss.capgemini.springboot.cruddemo.entity.Book;

@Repository
public class EmployeeDAOHibernateImpl implements BookDAO{
	// define field for entitymanager	
	private EntityManager entityManager;

	// set up constructor injection
	@Autowired
	public EmployeeDAOHibernateImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}

	@Override
	public List<Book> findAll() {

		// get the current hibernate session
		Session currentSession = entityManager.unwrap(Session.class);

		// create a query
		Query<Book> theQuery =
				currentSession.createQuery("from Book", Book.class);

		// execute query and get result list
		List<Book> employees = theQuery.getResultList();

		// return the results		
		return employees;
	}

	@Override
	public void save(Book theEmployee) {
		
		// get the current hibernate session
		Session currentSession = entityManager.unwrap(Session.class);
		
		// save employee
		currentSession.saveOrUpdate(theEmployee);

	}
}
