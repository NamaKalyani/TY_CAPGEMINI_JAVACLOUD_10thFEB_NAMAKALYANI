package com.capgemini.springboot.cruddemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.capgemini.springboot.cruddemo.dao.ProductRepository;
import com.capgemini.springboot.cruddemo.entity.Product;

@Service
public class ProductServiceImpl implements ProductService {

	private ProductRepository productRepository;

	@Autowired
	public ProductServiceImpl(ProductRepository theProductRepository) {
		productRepository = theProductRepository;
	}

	@Override
	public List<Product> findAllProducts() {

		return productRepository.findAll();
	}

	@Override
	public Product findProductById(int id) {

		Optional<Product> result = productRepository.findById(id);
		Product product= null;
		if (result.isPresent()) {
			product = result.get();
		} else {
			throw new RuntimeException("Didn't find the Product Id :" + id);
		}

		return product;
	}

	@Override
	public void save(Product product) {
		productRepository.save(product);
	}

	@Override
	public void deleteById(int id) {
		productRepository.deleteById(id);
	}

}
