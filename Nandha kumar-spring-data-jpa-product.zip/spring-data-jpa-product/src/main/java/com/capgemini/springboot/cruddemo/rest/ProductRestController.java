package com.capgemini.springboot.cruddemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springboot.cruddemo.entity.Product;
import com.capgemini.springboot.cruddemo.service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductRestController {

	private ProductService productService;

	@Autowired
	public ProductRestController(ProductService theProductService) {
		productService = theProductService;
	}

	// expose "/products" to return list of products
	@GetMapping("/products")
	public List<Product> findAllProducts() {

		return productService.findAllProducts();
	}

	// add mapping for GET /products/{productId}
	@GetMapping("/products/{productId}")
	public Product getProduct(@PathVariable int productId) {

		Product product = productService.findProductById(productId);

		if (product == null) {
			throw new RuntimeException("Product Id not found:" + productId);
		}

		return product;
	}

	// add mapping for POST /products - add new product
	@PostMapping("/products")
	public Product addProduct(@RequestBody Product product) {

		// also just in case they pass an id in JSON .... set id to 0
		// this is to force a save of new item .... instead of update
		product.setId(0);

		productService.save(product);

		return product;
	}

	// add mapping for PUT /products - update product
	@PutMapping("/products")
	public Product updateProduct(@RequestBody Product product) {

		productService.save(product);
		return product;
	}

	// add mapping for DELETE /products/{productId} - delete product
	@DeleteMapping("/products/{productId}")
	public String deleteUser(@PathVariable int productId) {

		Product thebook = productService.findProductById(productId);

		// throw exception if null
		if (thebook == null) {
			throw new RuntimeException("Product Id not found:" + productId);
		}
		productService.deleteById(productId);

		return "Deleted Product Id :" + productId;

	}
}
