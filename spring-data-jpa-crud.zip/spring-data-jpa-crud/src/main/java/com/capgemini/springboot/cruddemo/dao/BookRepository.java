package com.capgemini.springboot.cruddemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.springboot.cruddemo.entity.Book;

public interface BookRepository extends JpaRepository<Book, Integer> {

	//no need of implementation of methods we will get all the codes for free
	//methods are finall(),findById(),save(),deleteById().....
}
