package com.capgemini.springboot.cruddemo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.capgemini.springboot.cruddemo.dao.BookRepository;
import com.capgemini.springboot.cruddemo.entity.Book;

@Service
public class BookServiceImpl implements BookService {

	private BookRepository employeeRepository;

	@Autowired
	public BookServiceImpl(BookRepository thEmployeeRepository) {
		employeeRepository = thEmployeeRepository;
	}

	@Override
	@Transactional
	public List<Book> findAll() {
		
		return employeeRepository.findAll();
	}

	@Override
	public Book findById(int id) {
		Optional<Book> result = employeeRepository.findById(id);
		
		Book theEmployee = null;
		
		if(result.isPresent()) {
			theEmployee = result.get();
		}else {
			throw new RuntimeException("Did not find employee id " +id);
		}
		
		return theEmployee; 
	}

	@Override
	public void save(Book employee) {
		employeeRepository.save(employee);
	}

	@Override
	public void deleteById(int id) {
		employeeRepository.deleteById(id);
	}

}
