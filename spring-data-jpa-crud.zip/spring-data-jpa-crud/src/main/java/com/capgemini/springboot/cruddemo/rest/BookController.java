package com.capgemini.springboot.cruddemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springboot.cruddemo.entity.Book;
import com.capgemini.springboot.cruddemo.service.BookService;

@RestController
@RequestMapping("/api")
public class BookController {

	private BookService bookService;

	// inject EmployeeDAO (use constructor injection)
	@Autowired
	public BookController(BookService theBookService) {
		bookService = theBookService;
	}

	// expose "/employees" to return list of employees
	@GetMapping("/books")
	public List<Book> findAllBooks() {

		return bookService.findAll();
	}

	// add mapping for GET /employees/{employeeId}
	@GetMapping("/books/{bookId}")
	public Book geEmployee(@PathVariable int bookId) {

		Book book = bookService.findById(bookId);

		if (book == null) {
			throw new RuntimeException("Book Id not found:" + bookId);
		}

		return book;
	}

	// add mapping for POST /employees - add new employee
	@PostMapping("/employees")
	public Book addBooks(@RequestBody Book book) {

		// also just in case they pass an id in JSON .... set id to 0
		// this is to force a save of new item .... instead of update
		book.setBookId(0);

		bookService.save(book);

		return book;
	}

	// add mapping for PUT /employees - update employee
	@PutMapping("/books")
	public Book updateBook(@RequestBody Book book) {

		bookService.save(book);
		return book;
	}

	// add mapping for DELETE /employees/{employeeId} - delete employee
	@DeleteMapping("/books/{bookId}")
	public String deleteBook(@PathVariable int bookId) {

		Book thebook = bookService.findById(bookId);

		// throw exception if null
		if (thebook == null) {
			throw new RuntimeException("Employee Id not found:" + bookId);
		}
		bookService.deleteById(bookId);

		return "Deleted employee id :" + bookId;

	}
}
