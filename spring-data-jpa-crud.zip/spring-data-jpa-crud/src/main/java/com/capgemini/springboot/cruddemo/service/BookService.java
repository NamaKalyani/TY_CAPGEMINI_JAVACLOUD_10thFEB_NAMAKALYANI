package com.capgemini.springboot.cruddemo.service;

import java.util.List;

import com.capgemini.springboot.cruddemo.entity.Book;

public interface BookService {

	public List<Book> findAll();

	public Book findById(int id);

	public void save(Book book);

	public void deleteById(int id);
}
