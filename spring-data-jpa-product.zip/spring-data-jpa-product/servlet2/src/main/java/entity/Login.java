package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "employee_login")
public class Login {

	@Id
	@Column
	private Integer id;
	@Column
	private String email;
	@Column
	private String password;

}
