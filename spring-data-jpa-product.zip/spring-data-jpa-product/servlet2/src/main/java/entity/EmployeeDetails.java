package entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode.Exclude;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "employee_details")
public class EmployeeDetails implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer employeeId;
	@Column
	private String name;
	@Column(name = "email", unique = true)
	private String email;
	@Column(name = "departmentID", unique = true)
	private Integer deptID;
	@Column
	private String designation;
	@Column
	private double salary;
	@Column
	private LocalDate dateofbirth;
	@Column
	private LocalDate joiningDate;
	@Column(name = "mobile_no", unique = true)
	private long mobileno;
	@Column
	private Integer managerID;
	@Exclude
	@Column
	private String password;

}
