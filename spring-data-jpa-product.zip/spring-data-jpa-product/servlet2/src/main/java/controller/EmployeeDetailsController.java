package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.EmployeeDetailsDAO;
import dao.EmployeeDetailsDAOImpl;
import entity.EmployeeDetails;

@WebServlet("/EmployeeDetailsController")
public class EmployeeDetailsController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	RequestDispatcher dispatcher = null;
	EmployeeDetailsDAO employeeDetailsDAO = null;

	public EmployeeDetailsController() {
		employeeDetailsDAO = new EmployeeDetailsDAOImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");

		if (action == null) {
			action = "LIST";
		}

		switch (action) {
		case "LIST":
			listEmployees(request, response);
			break;

		case "EDIT":
			getSingleEmployee(request, response);
			break;

		case "DELETE":
			deleteEmployee(request, response);
			break;
			
		case "SEARCH":
			searchEmployee(request, response);

		default:
			listEmployees(request, response);
			break;
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("employeeId");
		String name = request.getParameter("name");
		LocalDate dob = LocalDate.parse(request.getParameter("dateofbirth"));
		LocalDate joiningDate =LocalDate.parse(request.getParameter("joiningDate"));
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String designation=request.getParameter("designation");
		String deptID = request.getParameter("deptID");
		String managerID =request.getParameter("managerID");
		String mobileno= request.getParameter("mobileno");
		String salary= request.getParameter("salary");

		EmployeeDetails ed = new EmployeeDetails();
		ed.setName(name);
//		ed.setEmployeeId(Integer.parseInt(id));
		ed.setEmail(email);
		ed.setPassword(password);
		ed.setDesignation(designation);
		ed.setDateofbirth(dob);
		ed.setJoiningDate(joiningDate);
		ed.setDeptID(Integer.parseInt(deptID));
		ed.setManagerID(Integer.parseInt(managerID));
		ed.setMobileno(Long.parseLong(mobileno));
		ed.setSalary(Double.parseDouble(salary));
	
		if (id.isEmpty() || id == null) {
			// save operation
			if (employeeDetailsDAO.saveEmployee(ed)) {
				request.setAttribute("message", "Saved successfully");
			}
		} else {
			// update operation
			ed.setEmployeeId(Integer.parseInt(id));
			if (employeeDetailsDAO.updateEmployee(ed)) {
				request.setAttribute("message", "Updated successfully");
			}
		}
		listEmployees(request, response);
	}

	public void listEmployees(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Call DAO method to get list of employees
		List<EmployeeDetails> list = employeeDetailsDAO.getAllEmployees();

		// Add the employees to request object
		request.setAttribute("list", list);

		// Get the request dispatcher
		dispatcher = request.getRequestDispatcher("/views/view-emp.jsp");

		// forward the request and response
		dispatcher.forward(request, response);
	}

	public void getSingleEmployee(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		EmployeeDetails employee = employeeDetailsDAO.getEmployees(Integer.parseInt(id));
		request.setAttribute("employee", employee);
		// Get the request dispatcher
		dispatcher = request.getRequestDispatcher("/views/add-emp.jsp");

		// forward the request and response
		dispatcher.forward(request, response);
	}

	public void deleteEmployee(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		if (employeeDetailsDAO.deleteEmployee(Integer.parseInt(id))) {
			request.setAttribute("message", "Record has been deleted successfully");
		}
		listEmployees(request, response);
	}
	
	public void searchEmployee(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		String id = request.getParameter("id");
		EmployeeDetails employeeDetails = employeeDetailsDAO.searchEmployee(Integer.parseInt(id));
		request.setAttribute("employeeDetails", employeeDetails);
		
		// Get the request dispatcher
		dispatcher = request.getRequestDispatcher("/views/search1.jsp");

		// forward the request and response
		dispatcher.forward(request, response);
	}

}
