package dao;

import java.util.List;

import entity.EmployeeDetails;

public interface EmployeeDetailsDAO {
	List<EmployeeDetails> getAllEmployees();

	public boolean saveEmployee(EmployeeDetails employee);

	EmployeeDetails getEmployees(int id);
	
	public EmployeeDetails searchEmployee(int id);

	public boolean updateEmployee(EmployeeDetails employee);

	public boolean deleteEmployee(int id);
}
