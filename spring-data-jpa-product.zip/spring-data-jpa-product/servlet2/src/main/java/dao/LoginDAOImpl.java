package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Login;

public class LoginDAOImpl implements LoginDAO {

	@Override
	public String authenticate(Login login) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		// get an login object
		Login login1 = entityManager.find(Login.class, 1);

		if ((login1.getEmail().equals("kalyani@gmail.com")) && (login1.getPassword().equals("123456"))) {
			return "true";
		} else {
			return "false";
		}
	}

}
