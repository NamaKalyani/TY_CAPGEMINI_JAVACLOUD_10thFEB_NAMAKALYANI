package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entity.EmployeeDetails;

public class EmployeeDetailsDAOImpl implements EmployeeDetailsDAO {

	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myPersistenceUnit");

	@Override
	@SuppressWarnings("unchecked")
	public List<EmployeeDetails> getAllEmployees() {

		EntityManager entityManager = entityManagerFactory.createEntityManager();

		EntityTransaction entityTransaction = entityManager.getTransaction();

		entityTransaction.begin();

		List<EmployeeDetails> listOfEmployees = entityManager.createQuery("from EmployeeDetails").getResultList();

		// commit transaction
		entityTransaction.commit();
		entityManager.close();

		return listOfEmployees;
	}

	@Override
	public boolean saveEmployee(EmployeeDetails employee) {

		EntityManager entityManager = entityManagerFactory.createEntityManager();

		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		entityManager.persist(employee);

		entityTransaction.commit();
		entityManager.close();
		return true;

	}

	@Override
	public boolean updateEmployee(EmployeeDetails employee) {

		EntityManager entityManager = entityManagerFactory.createEntityManager();

		EntityTransaction entityTransaction = entityManager.getTransaction();

		entityTransaction.begin();
		// save the student object
		Query query = entityManager.createQuery("update EmployeeDetails set name= '" + employee.getName().trim() + "',email='"
				+ employee.getEmail() + "',departmentID='" + employee.getDeptID() + "',designation='"
				+ employee.getDesignation() + "',salary='" + employee.getSalary() + "',dateofbirth='"
				+ employee.getDateofbirth() + "',joiningDate='" + employee.getJoiningDate() + "',mobile_no='"
				+ employee.getMobileno() + "',managerID='" + employee.getManagerID() + "',password='"
				+ employee.getPassword() + "' where employeeID=" + employee.getEmployeeId());
		query.executeUpdate();
		// commit transaction
		entityTransaction.commit();
		entityManager.close();
		return true;

	}

	@Override
	public boolean deleteEmployee(int id) {

		EntityManager entityManager = entityManagerFactory.createEntityManager();

		EntityTransaction entityTransaction = entityManager.getTransaction();

		entityTransaction.begin();

		// Delete a user object
		EmployeeDetails employee = entityManager.find(EmployeeDetails.class, id);
		if (employee != null) {
			entityManager.remove(employee);
		}

		// commit transaction
		entityTransaction.commit();
		entityManager.close();
		return true;
	}

	@Override
	public EmployeeDetails getEmployees(int id) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		// get an user object
		EmployeeDetails employeeDetails = entityManager.find(EmployeeDetails.class, id);

		entityManager.close();
		return employeeDetails;

	}

	@Override
	public EmployeeDetails searchEmployee(int id) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EmployeeDetails employeeDetails = entityManager.find(EmployeeDetails.class, id);

		entityManager.close();

		return employeeDetails;
	}
}
