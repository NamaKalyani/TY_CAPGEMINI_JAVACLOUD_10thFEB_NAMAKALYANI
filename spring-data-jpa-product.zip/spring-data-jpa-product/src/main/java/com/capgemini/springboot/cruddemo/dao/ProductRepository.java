package com.capgemini.springboot.cruddemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.springboot.cruddemo.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	void deleteByName(String productName);
	
	// no need to write code
}
