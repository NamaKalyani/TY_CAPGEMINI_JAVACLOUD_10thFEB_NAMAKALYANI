package com.capgemini.springboot.cruddemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springboot.cruddemo.entity.Product;
import com.capgemini.springboot.cruddemo.service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductRestController {

	private ProductService productService;

	@Autowired
	public ProductRestController(ProductService theproductService) {
		productService = theproductService;
	}

	// expose "/products" to return list of products
	@GetMapping("/products")
	public List<Product> findAllProducts() {

		return productService.findAllProducts();
	}

	// add mapping for GET /products/{studentId}
	@GetMapping("/products/{productName}")
	public Product getProduct(@PathVariable int productName) {

		Product product = productService.findProductByName(productName);

		if (product == null) {
			throw new RuntimeException("Product namenot found:" + productName);
		}

		return product;
	}

	// add mapping for POST /produts- add new product
	@PostMapping("/products")
	public Product addProduct(@RequestBody Product product) {

		

		productService.save(product);

		return product;
	}

	// add mapping for PUT /product - update product
	@PutMapping("/products")
	public Product updateProduct(@RequestBody Product product) {

		productService.save(product);
		return product;
	}

	// add mapping for DELETE /products/{productName} - delete product
	@DeleteMapping("/products/{productName}")
	public String deleteProduct(@PathVariable String productName) {

		Product theproduct = productService.findProductByName(productName);

		// throw exception if null
		if (theproduct == null) {
			throw new RuntimeException("Product Name not found:" + productName);
		}
		productService.deleteByName(productName);

		return "Deleted Product Name :" + productName;

	}
}
