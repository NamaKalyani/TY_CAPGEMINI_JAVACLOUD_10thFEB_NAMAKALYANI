package com.tyss.capgemini.springdemo;

public interface FortuneService {

	public String getFortune();
}
