package com.tyss.capgemini.springdemo;

public class TrackCoach implements Coach {
	
	private FortuneService fortuneService;
	
	public TrackCoach() {
		
	}
	
	//constructor
	public TrackCoach(FortuneService fortuneService) {
		super();
		this.fortuneService = fortuneService;
	}

	@Override
	public String getDailyWorkout() {
		
		return "run hard";
	}

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return "just do it:" + fortuneService.getFortune();
	}


}
