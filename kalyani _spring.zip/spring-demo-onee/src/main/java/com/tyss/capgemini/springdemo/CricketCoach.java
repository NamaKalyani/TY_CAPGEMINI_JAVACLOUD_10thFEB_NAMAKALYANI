package com.tyss.capgemini.springdemo;

public class CricketCoach implements Coach {

	private FortuneService fortuneService;
	
	//add new fields for emailaddress and team
	private String emailAddress;
	private String team;
	
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		System.out.println("cricketcoach: inside setter method-set emailAddress ");
		this.emailAddress = emailAddress;
	}

	
	public String getTeam() {
		return team;
	}

	
	public void setTeam(String team) {
		System.out.println("cricketcoach: inside setter method-set team ");
		this.team = team;
	}

	
	//create no argument constructor
	public CricketCoach() {
		System.out.println("cricketcoach: inside no argument constructor");
	}
	
	//setter method
	public void setFortuneService(FortuneService fortuneService) {
		System.out.println("cricketcoach: inside no argument constructor");
		this.fortuneService = fortuneService;
	}
	
	
	
	@Override
	public String getDailyWorkout() {
		return "practice fast bowling for 15 min";
	}


	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

}
